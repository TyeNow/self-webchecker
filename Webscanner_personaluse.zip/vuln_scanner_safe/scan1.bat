cd C:\Users\xxx\Desktop\vuln_scanner_safe
pip install -r requirements.txt
python scanner.py -u https://example.com
python scanner.py -u https://www.example.com --update --html
python scanner.py -u https://www.example.com -m sqli,xss,directory,info_leak